$(document).ready(function(){
	$('#reg-pic').delay(300).animate({left:0},"slow");
	$('#login-box').delay(300).animate({right:0},"slow");
});